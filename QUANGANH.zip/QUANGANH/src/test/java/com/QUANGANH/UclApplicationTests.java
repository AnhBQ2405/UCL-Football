package com.QUANGANH;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UclApplicationTests {

	@Test
	void contextLoads() {
	}

}
